//
//  ExpenseManagerData.swift
//  Expense Manager
//
//  Created by Mac Owner on 12/5/16.
//  Copyright © 2016 Niroshan Perera. All rights reserved.
//

import UIKit

class ExpenseManagerData {
    
    var budgets = [MonthlyBudget]()
    var budgetAmount: Float = 0.0
    
    let baseURLString = "https://budgget85.herokuapp.com"
    let session: NSURLSession = {
        let config = NSURLSessionConfiguration.defaultSessionConfiguration()
        return NSURLSession(configuration: config)
    }()
    
    
      func fetchMonthlyBudget(month: String) {
        let url = NSURL(string: "\(baseURLString)/main/budget")!
        let request = NSURLRequest(URL: url)
        
        let task = session.dataTaskWithRequest(request) {
            (data, response, error) -> Void in
            if let jsonData = data {
                do {
                    let jsonObject: AnyObject = try NSJSONSerialization.JSONObjectWithData(jsonData, options: .AllowFragments)
                    print(jsonObject)
                 
                    guard let
                        jsonDictionary = jsonObject as? [[NSObject:AnyObject]]
                        else {
                          return

                    }
                    
                    for budgetDictionary in jsonDictionary {
                        self.budgets.append(MonthlyBudget(id: (budgetDictionary["id"] as? Int)!, month: (budgetDictionary["month"] as? String)!, Amount: (budgetDictionary["Amount"] as? Float)!))
                    }
                    
                   // ViewController.setBudget(2000.00)
                    self.budgetAmount = self.budgets[0].Amount
                }
                catch let error {
                    print("Error creating JSON object: \(error)")
                }
                

            }
        }
        task.resume()
       // return self.budgets[0].Amount
    }
    
    
   

}