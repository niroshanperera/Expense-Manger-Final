//
//  MonthlyBudget.swift
//  Expense Manager
//
//  Created by Mac Owner on 12/7/16.
//  Copyright © 2016 Niroshan Perera. All rights reserved.
//

import UIKit
class MonthlyBudget : NSObject {
    var id : Int = 0
    var month : String = ""
    var Amount : Float = 0.00
    
    init(id: Int, month: String, Amount: Float) {
            self.id = id
            self.month = month
            self.Amount = Amount
    }
}