//
//  ViewController.swift
//  Expense Manager
//
//  Created by Mac Owner on 11/27/16.
//  Copyright © 2016 Niroshan Perera. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var budgets = [MonthlyBudget]()
    var budgetAmount: Float = 0.0
    
    let baseURLString = "https://budgget85.herokuapp.com"
    let session: NSURLSession = {
        let config = NSURLSessionConfiguration.defaultSessionConfiguration()
        return NSURLSession(configuration: config)
    }()

    var ExpenseAPI: ExpenseManagerData!
    var monthlyBudget: [MonthlyBudget] = [MonthlyBudget]()

    @IBOutlet weak var idMonth: UILabel!
    @IBOutlet weak var idDate: UILabel!
    @IBOutlet weak var idMaxBudget: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        
        let date = NSDate()
        
        let calendar = NSCalendar.currentCalendar()
        
        let components = calendar.components([.Day , .Month , .Year], fromDate: date)
        
        
        
        let year =  components.year
        
        let month = components.month
        
        let day = components.day
        idDate.text = String(month)+"/"+String(day)+"/"+String(year)
        idMonth.text = returnMonth(month)
    
        print(year)
        
        print(month)
        
        print(day)
        let x = setBudget("January")
        print(budgetAmount)
       
        // getting the montly budget
     //   ExpenseManagerData().fetchMonthlyBudget("January")
      //  idMaxBudget.text = String(budgetAmount)
    }
    
    
    func returnMonth(month: Int ) -> String {
        var months = [" ","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
        return(months[month])
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // set budet values
    func setBudget(month: String) -> Float {
        let url = NSURL(string: "https://budgget85.herokuapp.com/main/budget")!
        let request = NSURLRequest(URL: url)
        let task = session.dataTaskWithRequest(request) {
            (data, response, error) -> Void in
            if let jsonData = data {
                do {
                    let jsonObject: AnyObject = try NSJSONSerialization.JSONObjectWithData(jsonData, options: .AllowFragments)
                    print(jsonObject)
                    
                    guard let
                        jsonDictionary = jsonObject as? [[NSObject:AnyObject]]
                        else {
                            return
                            
                    }
                    
                    for budgetDictionary in jsonDictionary {
                        self.budgets.append(MonthlyBudget(id: (budgetDictionary["id"] as? Int)!, month: (budgetDictionary["month"] as? String)!, Amount: (budgetDictionary["Amount"] as? Float)!))
                    }
                    
                    print(self.budgets[0].Amount)
                    self.budgetAmount = self.budgets[0].Amount
                   // self.idMaxBudget?.text = String(self.budgets[0].Amount)
                    
                }
                catch let error {
                    print("Error creating JSON object: \(error)")
                }
                
                
            }
        }
        task.resume()
        return 3000.33
    }
        
    
        
}

